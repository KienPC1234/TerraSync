import React, { useState, useEffect } from 'react';
import ThreeScene from './ThreeScene';
import ControlPanel from './ControlPanel';
import './App.css';

const App = () => {
  const [showControlPanel, setShowControlPanel] = useState(false);
  const [weatherData, setWeatherData] = useState({
    air_temperature: 28,
    air_humidity: 60,
    rain_intensity: 0,
    wind_speed: 5,
    light_intensity: 1000,
    barometric_pressure: 1012,
  });

  useEffect(() => {
    const params = new URLSearchParams(window.location.search);
    const bangDK = params.get('BangDK');
    const show = bangDK === 'True' || bangDK === 'true';
    setShowControlPanel(show);

    if (!show) {
      const newSensors = {};
      let hasUpdates = false;
      const mappings = {
        'rain': 'rain_intensity',
        'humidity': 'air_humidity',
        'temperature': 'air_temperature',
        'wind': 'wind_speed',
        'light': 'light_intensity',
        'pressure': 'barometric_pressure'
      };

      for (const [param, key] of Object.entries(mappings)) {
        if (params.has(param)) {
          const val = parseFloat(params.get(param));
          if (!isNaN(val)) {
            newSensors[key] = val;
            hasUpdates = true;
          }
        }
      }

      if (hasUpdates) {
        setWeatherData(prev => ({
          ...prev,
          ...newSensors
        }));
      }
    }
  }, []);

  // Listen for postMessage from parent window
  useEffect(() => {
    const handleMessage = (event) => {
      const data = event.data;
      if (data && typeof data === 'object') {
        const newSensors = {};
        let hasUpdates = false;

        // Support direct state keys
        const stateKeys = [
          'air_temperature',
          'air_humidity',
          'rain_intensity',
          'wind_speed',
          'light_intensity',
          'barometric_pressure'
        ];

        stateKeys.forEach(key => {
          if (key in data) {
            const val = parseFloat(data[key]);
            if (!isNaN(val)) {
              newSensors[key] = val;
              hasUpdates = true;
            }
          }
        });

        // Support short keys (mapping)
        const mappings = {
          'rain': 'rain_intensity',
          'humidity': 'air_humidity',
          'temperature': 'air_temperature',
          'wind': 'wind_speed',
          'light': 'light_intensity',
          'pressure': 'barometric_pressure'
        };

        for (const [shortKey, stateKey] of Object.entries(mappings)) {
          if (shortKey in data && !(stateKey in newSensors)) {
            const val = parseFloat(data[shortKey]);
            if (!isNaN(val)) {
              newSensors[stateKey] = val;
              hasUpdates = true;
            }
          }
        }

        if (hasUpdates) {
          setWeatherData(prev => ({ ...prev, ...newSensors }));
        }
      }
    };

    window.addEventListener('message', handleMessage);
    return () => window.removeEventListener('message', handleMessage);
  }, []);

  return (
    <div className="App">
      {showControlPanel && (
        <div className="sidebar">
          <div className="sidebar-header">
            <h1>TerraSync</h1>
          </div>
          <ControlPanel 
            data={weatherData}
            setData={setWeatherData}
          />
        </div>
      )}
      <div className="main-content">
        <ThreeScene weather={weatherData} />
      </div>
    </div>
  );
};

export default App;
