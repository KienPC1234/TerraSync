import React from 'react';

const ControlPanel = ({ data, setData }) => {

  const handleChange = (key, value) => {
    setData(prev => ({ ...prev, [key]: parseFloat(value) }));
  };

  return (
    <div className="control-panel">
      <h2>Control Panel</h2>
      
      <div className="atm-controls">
        <h3>Weather Parameters</h3>
        
        <label>Air Temperature: {data.air_temperature.toFixed(2)} °C</label>
        <input 
          type="range" 
          min="-20" 
          max="50" 
          step="0.1" 
          value={data.air_temperature}
          onChange={(e) => handleChange('air_temperature', e.target.value)}
        />
        <label>Air Humidity: {data.air_humidity.toFixed(2)} %</label>
        <input 
          type="range" 
          min="0" 
          max="100" 
          step="0.1" 
          value={data.air_humidity}
          onChange={(e) => handleChange('air_humidity', e.target.value)}
        />
        <label>Rain Intensity: {data.rain_intensity.toFixed(2)} mm/h</label>
        <input 
          type="range" 
          min="0" 
          max="50" 
          step="0.1" 
          value={data.rain_intensity}
          onChange={(e) => handleChange('rain_intensity', e.target.value)}
        />
         <label>Wind Speed: {data.wind_speed.toFixed(2)} m/s</label>
        <input 
          type="range" 
          min="0" 
          max="30" 
          step="0.1" 
          value={data.wind_speed}
          onChange={(e) => handleChange('wind_speed', e.target.value)}
        />
        <label>Light Intensity: {data.light_intensity.toFixed(2)} Lux</label>
        <input 
          type="range" 
          min="0" 
          max="2000" 
          step="1" 
          value={data.light_intensity}
          onChange={(e) => handleChange('light_intensity', e.target.value)}
        />
        <label>Barometric Pressure: {data.barometric_pressure.toFixed(2)} hPa</label>
        <input 
          type="range" 
          min="900" 
          max="1100" 
          step="0.1" 
          value={data.barometric_pressure}
          onChange={(e) => handleChange('barometric_pressure', e.target.value)}
        />
      </div>
    </div>
  );
};

export default ControlPanel;