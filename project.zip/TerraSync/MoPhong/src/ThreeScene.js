import React, { useEffect, useMemo, useRef, useState } from 'react';
import { Canvas, useThree, useFrame } from '@react-three/fiber';
import { OrbitControls, Cloud, Stars, Environment } from '@react-three/drei';
import * as THREE from 'three';
// KHÔI PHỤC: Import file json của bạn
import sceneJson from './project.json'; 

// --- ColorOverlay Component (Giữ nguyên) ---
const ColorOverlay = ({ tintColor, opacity }) => {
  const { camera } = useThree();
  const mesh = useRef();
  useFrame(() => {
    if (mesh.current) {
      mesh.current.position.copy(camera.position);
      mesh.current.rotation.copy(camera.rotation);
      mesh.current.translateZ(-10); 
    }
  });
  return (
    <mesh ref={mesh}>
      <planeGeometry args={[100, 100]} />
      <meshBasicMaterial color={tintColor} transparent opacity={opacity} depthTest={false} />
    </mesh>
  );
};

// --- Lightning Component (Giữ nguyên) ---
const Lightning = ({ intensity }) => {
  const [flashOpacity, setFlashOpacity] = useState(0);
  useFrame(() => {
    if (intensity > 30 && Math.random() < 0.02) { // Tăng nhẹ tần suất chớp
      setFlashOpacity(0.8 + Math.random() * 0.2); 
    } else if (flashOpacity > 0) {
      setFlashOpacity(prev => Math.max(0, prev - 0.1)); 
    }
  });
  return (
    <>
      {flashOpacity > 0 && (
        <ambientLight intensity={flashOpacity * 10} color="#eeeeff" />
      )}
    </>
  );
};

// --- Rain Component (Đã sửa lại để nhìn rõ hơn) ---
const Rain = ({ count, wind, intensity }) => {
  const mesh = useRef();
  const group = useRef();
  const { camera } = useThree();

  const maxCount = 20000; 
  const rainRange = 1000; // Thu hẹp phạm vi rải hạt để mật độ dày hơn trước camera
  const boundary = rainRange / 2;
  const height = 600; 
  const halfHeight = height / 2;

  const velocities = useMemo(() => {
    const temp = new Float32Array(maxCount);
    for (let i = 0; i < maxCount; i++) {
      temp[i] = 60 + Math.random() * 30 + intensity * 5; // Rơi nhanh hơn
    }
    return temp;
  }, [maxCount, intensity]);

  const particles = useMemo(() => {
    const temp = [];
    for (let i = 0; i < maxCount; i++) {
      const x = THREE.MathUtils.randFloatSpread(rainRange);
      const y = THREE.MathUtils.randFloat(0, height);
      const z = THREE.MathUtils.randFloatSpread(rainRange);

      temp.push(x, y, z);
      
      // TĂNG ĐỘ DÀI HẠT MƯA để dễ nhìn thấy
      const streakLength = THREE.MathUtils.randFloat(20, 30) + intensity * 2; 
      const tiltX = THREE.MathUtils.randFloat(-1, 1);
      const tiltZ = THREE.MathUtils.randFloat(-1, 1);
      temp.push(x + tiltX, y - streakLength, z + tiltZ);
    }
    return new Float32Array(temp);
  }, [maxCount, rainRange, height, intensity]);

  useFrame((state, delta) => {
    if (group.current) {
      // Mưa đi theo camera
      group.current.position.set(camera.position.x, camera.position.y, camera.position.z); 
    }

    if (mesh.current) {
      const positions = mesh.current.geometry.attributes.position.array;
      const windSpeed = wind * 3.5; // Gió mạnh hơn
      const activeParticleCount = count; // Đảm bảo count được truyền vào lớn

      for (let i = 0; i < positions.length; i += 6) {
        const particleIndex = i / 6;

        if (particleIndex < activeParticleCount) {
          const fallSpeed = velocities[particleIndex] * delta;
          const turbulenceX = THREE.MathUtils.randFloat(-0.2, 0.2);
          
          positions[i] += (windSpeed * delta + turbulenceX);
          positions[i + 3] += (windSpeed * delta + turbulenceX);

          positions[i + 1] -= fallSpeed;
          positions[i + 4] -= fallSpeed;

          if (positions[i + 4] < -halfHeight) {
            const newY = halfHeight + THREE.MathUtils.randFloat(0, 150); 
            const newX = THREE.MathUtils.randFloatSpread(rainRange);
            const newZ = THREE.MathUtils.randFloatSpread(rainRange);
            const streakLength = THREE.MathUtils.randFloat(20, 30) + intensity * 2;
            const tiltX = windSpeed * 0.4; // Tilt theo gió

            positions[i] = newX; positions[i + 1] = newY; positions[i + 2] = newZ;
            positions[i + 3] = newX + tiltX; positions[i + 4] = newY - streakLength; positions[i + 5] = newZ;

            velocities[particleIndex] = 60 + Math.random() * 30 + intensity * 5;
          }

          if (positions[i] > boundary) { positions[i] -= rainRange; positions[i + 3] -= rainRange; }
          else if (positions[i] < -boundary) { positions[i] += rainRange; positions[i + 3] += rainRange; }
          if (positions[i + 2] > boundary) { positions[i + 2] -= rainRange; positions[i + 5] -= rainRange; }
          else if (positions[i + 2] < -boundary) { positions[i + 2] += rainRange; positions[i + 5] += rainRange; }
        } else {
          positions[i + 1] = -10000; positions[i + 4] = -10000;
        }
      }
      mesh.current.geometry.attributes.position.needsUpdate = true;
    }
  });

  return (
    <group ref={group}>
      <lineSegments ref={mesh}>
        <bufferGeometry>
          <bufferAttribute attach="attributes-position" count={particles.length / 3} array={particles} itemSize={3} />
        </bufferGeometry>
        {/* Tăng opacity và chỉnh màu sáng hơn để dễ thấy */}
        <lineBasicMaterial 
          color="#cceeff" 
          transparent 
          opacity={0.8} 
          linewidth={2} // Lưu ý: Một số trình duyệt giới hạn linewidth là 1
          depthTest={true}
        />
      </lineSegments>
    </group>
  );
};

// --- SceneContent Component ---
const SceneContent = ({ weather }) => {
  const { scene } = useThree();
  const cloudGroupRef = useRef();

  const lightInt = weather.light_intensity !== undefined ? weather.light_intensity : 1000;
  const activeEnvMap = lightInt < 300 ? 'ImageHDR/night.exr' : 'ImageHDR/morning.hdr';

  // --- KHÔI PHỤC: Load scene từ JSON ---
  useEffect(() => {
    const loader = new THREE.ObjectLoader();
    // Bọc trong try-catch để tránh crash nếu file lỗi, nhưng vẫn ưu tiên load file của bạn
    try {
        if (sceneJson) {
            const loadedScene = loader.parse(sceneJson.scene);
            loadedScene.children.slice().forEach(child => {
            if (!scene.getObjectByProperty('uuid', child.uuid)) {
                scene.add(child);
            }
            });
        }
    } catch (e) {
        console.error("Lỗi load project.json:", e);
    }
  }, [scene]);

  // --- Môi trường ---
  const humidity = weather.air_humidity !== undefined ? weather.air_humidity / 100 : 0.5;
  const rainIntensity = weather.rain_intensity !== undefined ? weather.rain_intensity : 0;
  const windSpeed = weather.wind_speed !== undefined ? weather.wind_speed : 5;
  const rainFactor = Math.min(rainIntensity / 50, 1);
  const elevation = THREE.MathUtils.mapLinear(lightInt, 0, 2000, -5, 90);
  const sunPosition = new THREE.Vector3();
  sunPosition.setFromSphericalCoords(100, THREE.MathUtils.degToRad(90 - elevation), Math.PI);

  useEffect(() => {
    const fogNear = 50 + (1 - humidity) * 200; 
    const fogFar = 200 + (1 - humidity) * 1500;
    const isNight = lightInt < 200;
    let fogColor = new THREE.Color(isNight ? '#050510' : '#e0e6ee'); 
    if (rainIntensity > 5) fogColor.lerp(new THREE.Color('#2a2a35'), rainFactor * 0.8);
    if (elevation > 0 && elevation < 15) fogColor.lerp(new THREE.Color('#ffaa88'), 0.5);
    scene.fog = new THREE.Fog(fogColor, fogNear, fogFar);
  }, [humidity, rainIntensity, lightInt, elevation, scene, rainFactor]);

  const temp = weather.air_temperature || 20;
  const tempFactor = THREE.MathUtils.clamp((temp - 20) / 30, -1, 1);
  const baseLight = lightInt / 1000;
  const fogDimming = 1.0 - humidity * 0.5;
  const rainDimming = 1.0 - rainFactor * 0.7;
  const finalLightLevel = Math.max(baseLight * rainDimming * fogDimming, 0.05); 
  const lightColor = new THREE.Color('#ffffff');
  if (tempFactor > 0) lightColor.lerp(new THREE.Color('#ffeedd'), tempFactor); 
  else lightColor.lerp(new THREE.Color('#ddeeff'), -tempFactor); 

  // --- CẤU HÌNH MÂY KHỔNG LỒ (Đã sửa cho TO hơn và SÁT nhau hơn) ---
  const pressure = weather.barometric_pressure || 1013;
  const pressureFactor = THREE.MathUtils.clamp((1013 - pressure) / 100, 0, 1); 
  const limitClouds = pressure > 1015;

  const baseCloudColor = pressureFactor > 0.5 ? new THREE.Color("#888899") : new THREE.Color("#ffffff");
  if (lightInt < 300) baseCloudColor.multiplyScalar(0.3);
  const internalCloudSpeed = (windSpeed / 40) + 0.05;

  const cloudConfigs = useMemo(() => {
    if (limitClouds) return [];

    const configs = [];
    // TĂNG KÍCH THƯỚC LÊN GẤP ĐÔI/GẤP BA
    // 1. Core Cloud (Siêu to khổng lồ)
    configs.push({
        pos: [0, 80, 0], // Hạ thấp xuống một chút để cảm giác đè nặng
        scale: 15, // Scale cực lớn
        width: 1500, // Rộng bao trùm
        depth: 500, // Rất dày
        segments: 150, // Đặc
        opacityBoost: 1.2
    });

    // 2. Satellites (Cũng rất to và chồng lấn)
    const satelliteCount = 5;
    const radius = 300; 
    for(let i=0; i < satelliteCount; i++) {
        const angle = (i / satelliteCount) * Math.PI * 2;
        const x = Math.cos(angle) * radius;
        const z = Math.sin(angle) * radius;
        
        configs.push({
            pos: [x, 70 + Math.random() * 30, z],
            scale: 10 + Math.random() * 5, // Scale to
            width: 1200, // Rộng để overlap
            depth: 400,
            segments: 100, // Đặc
            opacityBoost: 1.0
        });
    }
    return configs;
  }, [pressureFactor, limitClouds]);

  useFrame((state, delta) => {
    if (cloudGroupRef.current && windSpeed > 0) {
        const driftSpeed = windSpeed * 10; 
        cloudGroupRef.current.position.x += driftSpeed * delta;
        // Tăng giới hạn loop vì mây giờ rất to
        if (cloudGroupRef.current.position.x > 1500) {
            cloudGroupRef.current.position.x = -1500;
        }
    }
  });

  return (
    <>
      {activeEnvMap && <Environment files={activeEnvMap} background blur={0} />}
      {lightInt < 300 && <Stars radius={100} depth={50} count={5000} factor={4} saturation={0} fade speed={1} />}

      <ambientLight intensity={finalLightLevel * 0.4} color={lightColor} />
      <directionalLight
        position={sunPosition}
        intensity={finalLightLevel * 1.5} 
        color={lightColor}
        castShadow
        shadow-bias={-0.0005}
      >
        <orthographicCamera attach="shadow-camera" args={[-150, 150, 150, -150]} />
      </directionalLight>

      <OrbitControls makeDefault />
      
      {/* Mưa: Đảm bảo rain_intensity đủ lớn để thấy */}
      <Rain
        count={Math.floor(rainIntensity > 0 ? rainIntensity * 500 : 0)} 
        wind={windSpeed}
        intensity={rainIntensity}
      />
      
      <Lightning intensity={rainIntensity} />

      <group ref={cloudGroupRef}>
          {cloudConfigs.map((config, index) => {
             const finalOpacity = Math.min(humidity * config.opacityBoost * (0.6 + pressureFactor * 0.4), 1);
             return (
                <Cloud 
                    key={index}
                    position={config.pos} 
                    speed={internalCloudSpeed}
                    opacity={finalOpacity}
                    width={config.width}
                    depth={config.depth}
                    segments={config.segments}
                    color={baseCloudColor}
                    depthTest={true}
                    bounds={[config.width, 100, config.depth]} // Giới hạn vùng render hạt mây
                />
             );
          })}
      </group>

      {Math.abs(tempFactor) > 0.3 && (
        <ColorOverlay tintColor={tempFactor > 0 ? '#ff4500' : '#00bfff'} opacity={Math.abs(tempFactor) * 0.15} />
      )}
    </>
  );
};

const ThreeScene = ({ weather }) => {
  // Weather mặc định để test nếu không có props
  const defaultWeather = {
    light_intensity: 800,
    air_humidity: 90,
    rain_intensity: 60, // Mưa to để thấy rõ
    wind_speed: 15,
    air_temperature: 24,
    barometric_pressure: 1000
  };

  const activeWeather = weather && Object.keys(weather).length > 0 ? weather : defaultWeather;

  return (
    <Canvas
      style={{ height: '100%', width: '100%' }}
      camera={{ position: [0, 50, 150], fov: 65, near: 1, far: 5000 }} 
      shadows
      gl={{ toneMapping: THREE.ACESFilmicToneMapping, toneMappingExposure: 0.9 }} 
    >
      <SceneContent weather={activeWeather} /> 
    </Canvas>
  );
};

export default ThreeScene;