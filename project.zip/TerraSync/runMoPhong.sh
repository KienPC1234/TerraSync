cd MoPhong
npm start